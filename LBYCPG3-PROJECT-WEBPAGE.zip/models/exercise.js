const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Create Schema
const ExerciseSchema = new Schema({
  name: {
    type: String,
    required: true
  },
  description: {
    type: String,
    required: true
  },
  calories_burned_per_minute: {
    type: Number,
    required: true
  },
  met: {
    type: Number, // Change to integer
    required: true
  }
});

module.exports = mongoose.model('Exercise', ExerciseSchema);
