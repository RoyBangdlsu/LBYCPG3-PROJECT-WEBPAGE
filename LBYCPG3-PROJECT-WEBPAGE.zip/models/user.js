const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Create Schema
const UserSchema = new Schema({
  name: {
    type: String,
    required: true
  },
  goal: {
    type: String
  },
  goalType: {
    type: String
  },
  height: {
    type: Number
  },
  weight: {
    type: Number
  },
  gender: {
    type: String
  },
  username: {
    type: String,
    required: true,
    unique: true
  },
  password: {
    type: String,
    required: true
  },
  progress: [
    {
      date: {
        type: Date,
        default: Date.now
      },
      exerciseId: {
        type: Schema.Types.ObjectId,
        ref: 'Exercise',
        required: true
      },
      hours: {
        type: Number,
        required: true
      },
      sets: {
        type: Number,
        required: true
      },
      trials: {
        type: Number,
        required: true
      },
      caloriesBurned: {
        type: Number,
        required: true
      }
    }
  ]
});

module.exports = mongoose.model('User', UserSchema);
